import { MockMethod } from 'vite-plugin-mock'
