const webRoute = [
	/*{
		path: '/large-screen',
		component: ()=> import("@views/LargeScreen.vue")
	}*/
]
export default webRoute