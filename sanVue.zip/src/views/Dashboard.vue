<template>
	<h1>Dashboard</h1>
</template>

<script setup>
	
	ElMessageBox('1212')
</script>

<style>
</style>